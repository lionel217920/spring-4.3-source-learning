/**
 * SPI interfaces and configuration-related convenience classes for bean factories.
 */
package org.springframework.beans.factory.config;
